import React from 'react';
import { tradingStrategies, usageRecommendations } from './strategies/StrategyData';

const StrategyCard = ({ strategy }) => {
  return (
    <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md overflow-hidden border-l-4 border-amber-500 dark:border-amber-600 transition-all hover:shadow-lg">
      <div className="p-5">
        <div className="flex items-center mb-3">
          <div className="flex items-center justify-center w-8 h-8 rounded-full bg-amber-500 text-white font-bold text-sm mr-3">
            {strategy.id}
          </div>
          <h3 className="text-lg font-semibold text-gray-800 dark:text-white">{strategy.title}</h3>
        </div>
        
        <div className="flex flex-wrap gap-2 mb-3">
          {strategy.tags.map((tag, index) => (
            <span 
              key={index} 
              className="px-2 py-1 text-xs font-medium rounded-full bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-300"
            >
              {tag}
            </span>
          ))}
        </div>
        
        <p className="text-sm text-gray-600 dark:text-gray-300 mb-4">
          {strategy.description}
        </p>
        
        <div className="bg-gray-50 dark:bg-gray-900/50 rounded-md p-4 mb-4 border border-gray-200 dark:border-gray-700">
          <h4 className="text-sm font-semibold text-amber-600 dark:text-amber-400 mb-2">Formula</h4>
          <div className="font-mono text-sm text-gray-800 dark:text-gray-200">
            {strategy.formula.map((line, index) => (
              <div key={index} className="py-1">{line}</div>
            ))}
          </div>
          
          <div className="mt-3 pt-3 border-t border-gray-200 dark:border-gray-700">
            <div className="text-xs italic text-amber-600 dark:text-amber-400 mb-1">Where:</div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
              {strategy.parameters.map((param, index) => (
                <div key={index} className="flex text-xs">
                  {param.symbol && (
                    <span className="font-semibold text-blue-600 dark:text-blue-400 mr-2">
                      {param.symbol}
                    </span>
                  )}
                  {param.condition && (
                    <span className="font-semibold text-amber-600 dark:text-amber-400 mr-2">
                      {param.condition}
                    </span>
                  )}
                  <span className="text-gray-600 dark:text-gray-300">
                    {param.definition}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
        
        <div className="bg-blue-50 dark:bg-blue-900/20 rounded-md p-3 border-l-2 border-blue-500">
          <h4 className="text-xs font-semibold text-blue-700 dark:text-blue-400 mb-1">Logic</h4>
          <p className="text-xs text-gray-600 dark:text-gray-300">{strategy.logic}</p>
        </div>
      </div>
    </div>
  );
};

const RecommendationCard = ({ recommendation }) => {
  return (
    <div className="flex items-start p-4">
      <div className="flex items-center justify-center w-7 h-7 rounded-full bg-green-500 text-white font-bold text-xs mr-3 flex-shrink-0">
        {recommendation.id}
      </div>
      <div>
        <h4 className="text-sm font-semibold text-gray-800 dark:text-white mb-1">{recommendation.title}</h4>
        <p className="text-xs text-gray-600 dark:text-gray-300">{recommendation.description}</p>
      </div>
    </div>
  );
};

const AdminPage = () => {
  return (
    <div className="space-y-8">
      <header className="mb-8">
        <h1 className="text-4xl font-bold text-center text-primary dark:text-white">
          Advanced Trading Strategies
        </h1>
        <p className="mt-4 text-center text-gray-600 dark:text-gray-300 max-w-3xl mx-auto">
          Traditional sizing strategies rely on win rate and risk/reward ratio. These advanced strategies incorporate complex 
          financial metrics to provide a probabilistic edge in various market environments.
        </p>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {tradingStrategies.map(strategy => (
          <StrategyCard key={strategy.id} strategy={strategy} />
        ))}
      </div>

      <div className="mt-10 bg-white dark:bg-gray-800 rounded-lg shadow-md p-6">
        <h2 className="text-2xl font-bold text-center text-gray-800 dark:text-white mb-6 relative">
          <span className="relative">
            Usage Recommendations
            <span className="absolute bottom-0 left-0 w-full h-1 bg-amber-500 dark:bg-amber-600"></span>
          </span>
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {usageRecommendations.map(recommendation => (
            <RecommendationCard key={recommendation.id} recommendation={recommendation} />
          ))}
        </div>
      </div>
    </div>
  );
};

export default AdminPage;
